import React, { useState, useEffect, Component } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Bell, 
  Settings, 
  LogOut, 
  Plus, 
  CheckCircle, 
  XCircle, 
  LayoutDashboard,
  Palette,
  Image as ImageIcon,
  Dumbbell,
  Trash2,
  Edit,
  UserPlus,
  History,
  Megaphone,
  QrCode,
  Camera
} from 'lucide-react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { 
  collection, 
  query, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc,
  doc, 
  orderBy,
  limit,
  where,
  getDocFromServer,
  setDoc
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { useAuth } from './services/authService';
import { UserRole, Workout, CheckIn, UserProfile } from './types';
import { cn } from './lib/utils';
import { Logo } from './components/Logo';

import { ErrorBoundary } from './components/ErrorBoundary';
import { handleFirestoreError, OperationType } from './lib/firestoreUtils';

// --- Components ---

const Card = ({ children, className }: { children: React.ReactNode; className?: string }) => (
  <div className={cn("glass p-6 rounded-2xl", className)}>
    {children}
  </div>
);

const Button = ({ 
  children, 
  onClick, 
  variant = 'primary', 
  className,
  disabled
}: { 
  children: React.ReactNode; 
  onClick?: () => void; 
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  className?: string;
  disabled?: boolean;
}) => {
  const variants = {
    primary: "bg-[var(--primary)] text-black font-bold hover:neon-glow disabled:opacity-50",
    secondary: "bg-[var(--secondary)] text-white font-bold disabled:opacity-50",
    ghost: "bg-transparent text-white border border-[var(--border)] hover:bg-white/5 disabled:opacity-50",
    danger: "bg-red-500/20 text-red-500 border border-red-500/50 hover:bg-red-500/30 disabled:opacity-50"
  };

  return (
    <button 
      type="button"
      onClick={(e) => {
        if (onClick && !disabled) {
          e.preventDefault();
          onClick();
        }
      }}
      disabled={disabled}
      className={cn("px-4 py-2 rounded-xl transition-all duration-200 active:scale-95 cursor-pointer", variants[variant], className)}
    >
      {children}
    </button>
  );
};

const Modal = ({ 
  isOpen, 
  onClose, 
  title, 
  children,
  footer
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  title: string; 
  children: React.ReactNode;
  footer?: React.ReactNode;
}) => (
  <AnimatePresence>
    {isOpen && (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        />
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative w-full max-w-md glass p-6 rounded-3xl border border-white/10 shadow-2xl"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-black uppercase italic tracking-tight">{title}</h3>
            <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full transition-colors">
              <XCircle className="w-5 h-5" />
            </button>
          </div>
          <div className="space-y-4">
            {children}
          </div>
          {footer && (
            <div className="mt-8 flex gap-3">
              {footer}
            </div>
          )}
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);

// --- Views ---

const LoginView = ({ onLogin }: { onLogin: (id: string, rememberMe: boolean) => Promise<string | null> }) => {
  const [id, setId] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const handleLogin = async () => {
    if (!id.trim()) {
      setError('Please enter your ID');
      return;
    }
    try {
      setError(null);
      setIsLoggingIn(true);
      const errorMsg = await onLogin(id, rememberMe);
      if (errorMsg) {
        setError(errorMsg);
      }
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred');
    } finally {
      setIsLoggingIn(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <Card className="text-center space-y-8">
          <div className="flex justify-center">
            <Logo size="lg" />
          </div>
          
          <div className="space-y-2">
            <h1 className="text-3xl font-black tracking-tighter uppercase italic">IronCore</h1>
            <p className="text-[var(--text-muted)]">Access your fitness portal</p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <input 
                type="text" 
                placeholder="e.g. 1234567890"
                maxLength={15}
                value={id}
                onChange={(e) => {
                  setId(e.target.value);
                  setError(null);
                }}
                className={cn(
                  "w-full bg-black/50 border rounded-xl px-4 py-3 focus:neon-border outline-none transition-all text-center text-xl font-mono",
                  error ? "border-red-500" : "border-[var(--border)]"
                )}
              />
              {error && (
                <motion.p 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="text-red-500 text-sm font-medium"
                >
                  {error}
                </motion.p>
              )}
            </div>

            <div className="flex items-center justify-between px-1">
              <label className="flex items-center gap-2 cursor-pointer group">
                <div 
                  className={cn(
                    "w-5 h-5 rounded border flex items-center justify-center transition-all",
                    rememberMe ? "bg-[var(--primary)] border-[var(--primary)]" : "border-[var(--border)] group-hover:border-white/30"
                  )}
                >
                  {rememberMe && <CheckCircle className="w-4 h-4 text-black" />}
                </div>
                <input 
                  type="checkbox" 
                  className="sr-only" 
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                />
                <span className="text-sm text-[var(--text-muted)] group-hover:text-white transition-colors">Remember Me</span>
              </label>
            </div>

            <Button onClick={handleLogin} disabled={isLoggingIn} className="w-full py-4 text-lg">
              {isLoggingIn ? 'Verifying...' : 'Check In'}
            </Button>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

const SuperAdminDashboard = ({ isLocalMode, setActiveTab }: { isLocalMode: boolean, setActiveTab: (tab: string) => void }) => {
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [status, setStatus] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'workouts'), orderBy('createdAt', 'desc'));
    return onSnapshot(q, (snapshot) => {
      setWorkouts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Workout)));
    });
  }, []);

  const showStatus = (msg: string) => {
    setStatus(msg);
    setTimeout(() => setStatus(null), 3000);
  };

  const addWorkout = async () => {
    if (isLocalMode) {
      showStatus('Cannot add in Local Mode');
      return;
    }
    try {
      await addDoc(collection(db, 'workouts'), {
        title: 'New Workout',
        description: 'Custom routine',
        exercises: [],
        createdBy: auth.currentUser?.uid,
        createdAt: Date.now()
      });
      showStatus('Workout added!');
    } catch (err) {
      console.error('Failed to add workout:', err);
      showStatus('Error adding workout');
    }
  };

  const handleTheme = () => showStatus('Theme Editor coming soon');
  const handleBrand = () => showStatus('Branding tools coming soon');

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-black uppercase italic tracking-tight">Super Admin Panel</h2>
          {status && (
            <motion.span 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-xs font-bold text-[var(--primary)] bg-[var(--primary)]/10 px-2 py-1 rounded"
            >
              {status}
            </motion.span>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={handleTheme} className="flex items-center gap-2">
            <Palette className="w-4 h-4" /> Theme
          </Button>
          <Button variant="ghost" onClick={handleBrand} className="flex items-center gap-2">
            <ImageIcon className="w-4 h-4" /> Logo
          </Button>
        </div>
      </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="space-y-4 border-l-4 border-[var(--primary)]">
            <div className="flex items-center justify-between">
              <h3 className="font-bold">Member Management</h3>
              <Users className="w-5 h-5 text-[var(--primary)]" />
            </div>
            <p className="text-sm text-[var(--text-muted)]">Add admins, managers, or members and manage their profiles.</p>
            <Button variant="primary" onClick={() => setActiveTab('members')} className="w-full">Manage Users</Button>
          </Card>

          <Card className="space-y-4 border-l-4 border-[var(--secondary)]">
          <div className="flex items-center justify-between">
            <h3 className="font-bold">System Theme</h3>
            <Palette className="w-5 h-5 text-[var(--secondary)]" />
          </div>
          <p className="text-sm text-[var(--text-muted)]">Adjust colors, fonts, and visual styles of the app.</p>
          <Button variant="secondary" onClick={handleTheme} className="w-full">Open Editor</Button>
        </Card>

        <Card className="space-y-4 border-l-4 border-blue-500">
          <div className="flex items-center justify-between">
            <h3 className="font-bold">Branding</h3>
            <ImageIcon className="w-5 h-5 text-blue-500" />
          </div>
          <p className="text-sm text-[var(--text-muted)]">Update gym logo, name, and contact information.</p>
          <Button variant="ghost" onClick={handleBrand} className="w-full">Update Brand</Button>
        </Card>
      </div>
    </div>
  );
};

const BroadcastPanel = ({ isLocalMode }: { isLocalMode: boolean }) => {
  const [message, setMessage] = useState('');
  const [broadcasts, setBroadcasts] = useState<any[]>([]);
  const [status, setStatus] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'broadcasts'), orderBy('timestamp', 'desc'), limit(10));
    return onSnapshot(q, (snapshot) => {
      setBroadcasts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
  }, []);

  const sendBroadcast = async () => {
    if (isLocalMode) {
      setStatus('Local mode: cannot send');
      return;
    }
    if (!message.trim()) return;
    try {
      await addDoc(collection(db, 'broadcasts'), {
        message,
        timestamp: Date.now(),
        sender: auth.currentUser?.uid
      });
      setMessage('');
      setStatus('Broadcast sent!');
      setTimeout(() => setStatus(null), 3000);
    } catch (err) {
      console.error('Broadcast failed:', err);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-black uppercase italic tracking-tight">Broadcast Center</h2>
        {status && <span className="text-xs font-bold text-[var(--primary)]">{status}</span>}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-1 space-y-4">
          <h3 className="font-bold">New Message</h3>
          <textarea 
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type your announcement here..."
            className="w-full h-32 bg-white/5 border border-white/10 rounded-xl p-4 text-sm focus:outline-none focus:border-[var(--primary)]"
          />
          <Button variant="primary" onClick={sendBroadcast} className="w-full">Send to All Members</Button>
        </Card>

        <Card className="md:col-span-2 space-y-4">
          <h3 className="font-bold flex items-center gap-2">
            <History className="w-5 h-5" /> Recent Broadcasts
          </h3>
          <div className="space-y-3">
            {broadcasts.map(b => (
              <div key={b.id} className="p-4 bg-white/5 rounded-xl border border-white/5">
                <p className="text-sm">{b.message}</p>
                <p className="text-[10px] text-[var(--text-muted)] mt-2">
                  {new Date(b.timestamp).toLocaleString()}
                </p>
              </div>
            ))}
            {broadcasts.length === 0 && (
              <p className="text-center text-[var(--text-muted)] py-8 text-sm italic">No history</p>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

const MemberManagement = ({ isLocalMode }: { isLocalMode: boolean }) => {
  const [members, setMembers] = useState<UserProfile[]>([]);
  const [selectedMember, setSelectedMember] = useState<UserProfile | null>(null);
  const [memberHistory, setMemberHistory] = useState<CheckIn[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [isAdding, setIsAdding] = useState(false);
  const [editForm, setEditForm] = useState({ name: '', role: UserRole.MEMBER, id: '' });
  const [addForm, setAddForm] = useState({ name: '', role: UserRole.MEMBER, id: '' });
  const [status, setStatus] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  useEffect(() => {
    const qMembers = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
    const unsubMembers = onSnapshot(qMembers, (snapshot) => {
      const allUsers = snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile));
      setMembers(allUsers.filter(u => u.role !== UserRole.SUPER_ADMIN));
    });
    return () => unsubMembers();
  }, []);

  useEffect(() => {
    if (selectedMember) {
      const q = query(
        collection(db, 'checkins'), 
        where('memberId', '==', selectedMember.id),
        orderBy('timestamp', 'desc')
      );
      return onSnapshot(q, (snapshot) => {
        setMemberHistory(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CheckIn)));
      });
    }
  }, [selectedMember]);

  const showStatus = (msg: string) => {
    setStatus(msg);
    setTimeout(() => setStatus(null), 3000);
  };

  const handleDeleteMember = async () => {
    if (!confirmDelete) return;
    if (isLocalMode) {
      showStatus('Local mode: cannot delete');
      setConfirmDelete(null);
      return;
    }
    try {
      await deleteDoc(doc(db, 'users', confirmDelete));
      showStatus('Member deleted');
      setConfirmDelete(null);
    } catch (err) {
      console.error('Failed to delete member:', err);
      showStatus('Error deleting member');
    }
  };

  const handleEditMember = (member: UserProfile) => {
    setEditForm({ name: member.name, role: member.role, id: member.id });
    setSelectedMember(member);
    setIsEditing(true);
  };

  const saveMemberChanges = async () => {
    if (isLocalMode) {
      showStatus('Local mode: cannot save');
      return;
    }
    if (!selectedMember) return;
    if (!editForm.name.trim() || !editForm.id.trim()) {
      showStatus('Name and ID are required');
      return;
    }
    try {
      await updateDoc(doc(db, 'users', selectedMember.uid), {
        name: editForm.name,
        role: editForm.role,
        id: editForm.id
      });
      setIsEditing(false);
      setSelectedMember(null);
      showStatus('Changes saved');
    } catch (err) {
      console.error('Failed to update member:', err);
      showStatus('Error saving changes');
    }
  };

  const handleAddMember = async () => {
    if (isLocalMode) {
      showStatus('Local mode: cannot add');
      return;
    }
    if (!addForm.name.trim() || !addForm.id.trim()) {
      showStatus('Name and ID are required');
      return;
    }
    try {
      // Use ID as document ID for easier migration during login
      const path = `users/${addForm.id}`;
      await setDoc(doc(db, 'users', addForm.id), {
        name: addForm.name,
        id: addForm.id,
        role: addForm.role,
        createdAt: Date.now(),
        uid: addForm.id // Initial UID is the ID itself
      });
      setIsAdding(false);
      setAddForm({ name: '', role: UserRole.MEMBER, id: '' });
      showStatus('User added');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `users/${addForm.id}`);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-black uppercase italic tracking-tight">Member Management</h2>
          {status && <span className="text-xs font-bold text-[var(--primary)]">{status}</span>}
        </div>
        <Button variant="primary" onClick={() => setIsAdding(true)} className="flex items-center gap-2">
          <UserPlus className="w-4 h-4" /> Add User
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 space-y-4">
          <div className="space-y-2">
            {members.length === 0 ? (
              <p className="text-center py-12 text-[var(--text-muted)] italic">No members found</p>
            ) : (
              members.map(member => (
                <div key={member.uid} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:border-white/10 transition-all">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center font-bold text-lg">
                      {member.name[0]}
                    </div>
                    <div>
                      <p className="font-bold">{member.name}</p>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] uppercase tracking-widest text-[var(--text-muted)]">ID: {member.id}</span>
                        <span className="w-1 h-1 rounded-full bg-white/20" />
                        <span className="text-[10px] uppercase font-bold text-[var(--primary)]">{member.role}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => setSelectedMember(member)} className="p-2 text-[var(--text-muted)] hover:text-white"><History className="w-5 h-5" /></button>
                    <button onClick={() => handleEditMember(member)} className="p-2 text-[var(--text-muted)] hover:text-[var(--primary)]"><Edit className="w-5 h-5" /></button>
                    <button onClick={() => setConfirmDelete(member.uid)} className="p-2 text-[var(--text-muted)] hover:text-red-500"><Trash2 className="w-5 h-5" /></button>
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>

        <div className="space-y-6">
          {selectedMember && !isEditing && (
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold">History: {selectedMember.name}</h3>
                <button onClick={() => setSelectedMember(null)} className="text-xs text-[var(--text-muted)]">Close</button>
              </div>
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                {memberHistory.length === 0 ? (
                  <p className="text-center py-8 text-xs text-[var(--text-muted)] italic">No history available</p>
                ) : (
                  memberHistory.map(ci => (
                    <div key={ci.id} className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5">
                      <div>
                        <p className="text-xs font-bold">{ci.day || new Date(ci.timestamp).toLocaleDateString()}</p>
                        <p className="text-[10px] text-[var(--text-muted)]">{ci.time || new Date(ci.timestamp).toLocaleTimeString()}</p>
                      </div>
                      <span className={cn("text-[9px] px-2 py-0.5 rounded-full uppercase font-bold", ci.status === 'approved' ? "bg-green-500/20 text-green-500" : "bg-red-500/20 text-red-500")}>{ci.status}</span>
                    </div>
                  ))
                )}
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* Add User Modal */}
      <Modal 
        isOpen={isAdding} 
        onClose={() => setIsAdding(false)} 
        title="Add New User"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsAdding(false)} className="flex-1">Cancel</Button>
            <Button variant="primary" onClick={handleAddMember} className="flex-1">Add User</Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)]">Full Name</label>
            <input 
              type="text" 
              value={addForm.name} 
              onChange={(e) => setAddForm({...addForm, name: e.target.value})} 
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:neon-border outline-none transition-all" 
              placeholder="e.g. John Doe" 
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)]">Member ID</label>
            <input 
              type="text" 
              value={addForm.id} 
              onChange={(e) => setAddForm({...addForm, id: e.target.value})} 
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:neon-border outline-none transition-all" 
              placeholder="e.g. 1234567890" 
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)]">Role</label>
            <select 
              value={addForm.role} 
              onChange={(e) => setAddForm({...addForm, role: e.target.value as UserRole})} 
              className="w-full bg-zinc-900 border border-white/10 rounded-xl px-4 py-3 text-sm focus:neon-border outline-none transition-all"
            >
              <option value={UserRole.MEMBER}>Member</option>
              <option value={UserRole.MANAGER}>Manager</option>
              <option value={UserRole.ADMIN}>Admin</option>
            </select>
          </div>
        </div>
      </Modal>

      {/* Edit User Modal */}
      <Modal 
        isOpen={isEditing} 
        onClose={() => setIsEditing(false)} 
        title="Edit Profile"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsEditing(false)} className="flex-1">Cancel</Button>
            <Button variant="primary" onClick={saveMemberChanges} className="flex-1">Save Changes</Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)]">Full Name</label>
            <input 
              type="text" 
              value={editForm.name} 
              onChange={(e) => setEditForm({...editForm, name: e.target.value})} 
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:neon-border outline-none transition-all" 
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)]">Member ID</label>
            <input 
              type="text" 
              value={editForm.id} 
              onChange={(e) => setEditForm({...editForm, id: e.target.value})} 
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:neon-border outline-none transition-all" 
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)]">Role</label>
            <select 
              value={editForm.role} 
              onChange={(e) => setEditForm({...editForm, role: e.target.value as UserRole})} 
              className="w-full bg-zinc-900 border border-white/10 rounded-xl px-4 py-3 text-sm focus:neon-border outline-none transition-all"
            >
              <option value={UserRole.MEMBER}>Member</option>
              <option value={UserRole.MANAGER}>Manager</option>
              <option value={UserRole.ADMIN}>Admin</option>
            </select>
          </div>
        </div>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal 
        isOpen={!!confirmDelete} 
        onClose={() => setConfirmDelete(null)} 
        title="Confirm Deletion"
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirmDelete(null)} className="flex-1">Cancel</Button>
            <Button variant="danger" onClick={handleDeleteMember} className="flex-1">Delete Member</Button>
          </>
        }
      >
        <p className="text-sm text-[var(--text-muted)]">Are you sure you want to delete this member? This action cannot be undone.</p>
      </Modal>
    </div>
  );
};

const StaffDashboard = ({ isLocalMode, setActiveTab }: { isLocalMode: boolean, setActiveTab: (tab: string) => void }) => {
  const [checkins, setCheckins] = useState<CheckIn[]>([]);
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [status, setStatus] = useState<string | null>(null);

  useEffect(() => {
    const qCheckins = query(collection(db, 'checkins'), orderBy('timestamp', 'desc'), limit(50));
    const unsubCheckins = onSnapshot(qCheckins, (snapshot) => {
      setCheckins(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CheckIn)));
    });

    const qWorkouts = query(collection(db, 'workouts'), orderBy('createdAt', 'desc'), limit(10));
    const unsubWorkouts = onSnapshot(qWorkouts, (snapshot) => {
      setWorkouts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Workout)));
    });

    return () => {
      unsubCheckins();
      unsubWorkouts();
    };
  }, []);

  const showStatus = (msg: string) => {
    setStatus(msg);
    setTimeout(() => setStatus(null), 3000);
  };

  const handleCheckIn = async (id: string, status: 'approved' | 'rejected') => {
    if (isLocalMode) {
      showStatus('Cannot update in Local Mode');
      return;
    }
    try {
      await updateDoc(doc(db, 'checkins', id), { status });
    } catch (err) {
      console.error('Failed to update check-in:', err);
    }
  };

  const addWorkout = async () => {
    if (isLocalMode) {
      showStatus('Cannot add in Local Mode');
      return;
    }
    try {
      await addDoc(collection(db, 'workouts'), {
        title: 'New Workout',
        description: 'Custom routine',
        exercises: [],
        createdBy: auth.currentUser?.uid,
        createdAt: Date.now()
      });
      showStatus('Workout added!');
    } catch (err) {
      console.error('Failed to add workout:', err);
      showStatus('Error adding workout');
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-black uppercase italic tracking-tight">Staff Dashboard</h2>
          {status && (
            <motion.span 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-xs font-bold text-[var(--primary)] bg-[var(--primary)]/10 px-2 py-1 rounded"
            >
              {status}
            </motion.span>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={() => setActiveTab('members')} className="flex items-center gap-2">
            <Users className="w-4 h-4" /> Members
          </Button>
          <Button variant="primary" onClick={addWorkout} className="flex items-center gap-2">
            <Plus className="w-4 h-4" /> Add Workout
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pending Check-ins */}
        <Card className="lg:col-span-1 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-[var(--primary)]" /> Pending
            </h3>
          </div>
          <div className="space-y-2">
            {checkins.filter(c => c.status === 'pending').map(ci => (
              <div key={ci.id} className="p-4 bg-white/5 border border-white/10 rounded-xl flex items-center justify-between">
                <div>
                  <p className="font-bold text-sm">{ci.memberName}</p>
                  <p className="text-xs opacity-70">ID: {ci.memberId}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleCheckIn(ci.id, 'rejected')} className="p-2 bg-red-500/20 text-red-500 rounded-lg hover:bg-red-500/30 transition-colors">
                    <XCircle className="w-5 h-5" />
                  </button>
                  <button onClick={() => handleCheckIn(ci.id, 'approved')} className="p-2 bg-[var(--primary)] text-black rounded-lg hover:neon-glow transition-colors">
                    <CheckCircle className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
            {checkins.filter(c => c.status === 'pending').length === 0 && (
              <p className="text-center text-[var(--text-muted)] py-8 text-sm italic">No pending requests</p>
            )}
          </div>
        </Card>

        {/* Recent Activity */}
        <Card className="lg:col-span-1 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold flex items-center gap-2">
              <History className="w-5 h-5" /> Activity
            </h3>
          </div>
          <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
            {checkins.map(ci => (
              <div key={ci.id} className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-xs">
                    {ci.memberName[0]}
                  </div>
                  <div>
                    <p className="font-medium text-sm">{ci.memberName}</p>
                    <p className="text-xs text-[var(--text-muted)]">
                      {ci.day ? `${ci.day}, ${ci.time}` : new Date(ci.timestamp).toLocaleString()}
                    </p>
                  </div>
                </div>
                <span className={cn(
                  "text-[10px] px-2 py-1 rounded-full uppercase font-bold",
                  ci.status === 'approved' ? "bg-green-500/20 text-green-500" : 
                  ci.status === 'rejected' ? "bg-red-500/20 text-red-500" : "bg-yellow-500/20 text-yellow-500"
                )}>
                  {ci.status}
                </span>
              </div>
            ))}
          </div>
        </Card>

        {/* Recent Workouts */}
        <Card className="lg:col-span-1 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold flex items-center gap-2">
              <Dumbbell className="w-5 h-5 text-[var(--secondary)]" /> Workouts
            </h3>
          </div>
          <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
            {workouts.map(w => (
              <div key={w.id} className="p-3 bg-white/5 rounded-xl border border-white/5">
                <p className="font-bold text-sm">{w.title}</p>
                <p className="text-xs text-[var(--text-muted)]">{w.description}</p>
              </div>
            ))}
            {workouts.length === 0 && (
              <p className="text-center text-[var(--text-muted)] py-8 text-sm italic">No workouts yet</p>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

const MemberDashboard = ({ user }: { user: any }) => {
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [showScanner, setShowScanner] = useState(false);
  const [myCheckins, setMyCheckins] = useState<CheckIn[]>([]);

  useEffect(() => {
    const q = query(collection(db, 'workouts'), limit(5));
    return onSnapshot(q, (snapshot) => {
      setWorkouts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Workout)));
    });
  }, []);

  useEffect(() => {
    const q = query(
      collection(db, 'checkins'), 
      where('memberId', '==', user.id)
    );
    return onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CheckIn));
      setMyCheckins(docs.sort((a, b) => b.timestamp - a.timestamp).slice(0, 10));
    });
  }, [user.id]);

  const [broadcasts, setBroadcasts] = useState<any[]>([]);

  useEffect(() => {
    const q = query(collection(db, 'broadcasts'), orderBy('timestamp', 'desc'), limit(3));
    return onSnapshot(q, (snapshot) => {
      setBroadcasts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
  }, []);

  useEffect(() => {
    if (showScanner) {
      const scanner = new Html5QrcodeScanner(
        "reader",
        { fps: 10, qrbox: { width: 250, height: 250 } },
        false
      );

      const onScanSuccess = (decodedText: string) => {
        if (decodedText === 'IRONCORE_GYM_CHECKIN') {
          performCheckIn('approved');
          setShowScanner(false);
        }
      };

      scanner.render(onScanSuccess, (err) => {
        // Ignore failures
      });

      return () => {
        scanner.clear().catch(error => {
          console.error("Failed to clear html5QrcodeScanner.", error);
        });
      };
    }
  }, [showScanner]);

  const performCheckIn = async (status: 'pending' | 'approved' = 'pending') => {
    try {
      const now = new Date();
      const day = now.toLocaleDateString('en-US', { weekday: 'long' });
      const time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      
      await addDoc(collection(db, 'checkins'), {
        memberId: user.id,
        memberName: user.name,
        timestamp: Date.now(),
        day,
        time,
        status
      });
      setStatusMsg(status === 'approved' ? 'Check-in successful!' : 'Check-in request sent!');
      setTimeout(() => setStatusMsg(null), 3000);
    } catch (err) {
      console.error('Check-in failed:', err);
      setStatusMsg('Failed to check in.');
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-black uppercase italic tracking-tight">My Workouts</h2>
        <div className="flex items-center gap-4">
          {statusMsg && (
            <motion.span 
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-sm text-[var(--primary)] font-bold"
            >
              {statusMsg}
            </motion.span>
          )}
          <div className="flex gap-2">
            <Button onClick={() => setShowScanner(!showScanner)} variant="secondary" className="flex items-center gap-2">
              <QrCode className="w-4 h-4" /> {showScanner ? 'Close Scanner' : 'Scan QR'}
            </Button>
            <Button onClick={() => performCheckIn('pending')} variant="primary" className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4" /> Request Manual
            </Button>
          </div>
        </div>
      </div>

      {showScanner && (
        <Card className="max-w-md mx-auto overflow-hidden">
          <div id="reader" className="w-full"></div>
          <p className="text-center text-xs text-[var(--text-muted)] mt-4">
            Scan the gym's QR code to check in automatically.
          </p>
        </Card>
      )}

      <div className="grid grid-cols-1 gap-6">
        {broadcasts.length > 0 && (
          <Card className="bg-[var(--primary)]/5 border-[var(--primary)]/20">
            <h3 className="font-bold flex items-center gap-2 mb-4">
              <Megaphone className="w-5 h-5 text-[var(--primary)]" /> Announcements
            </h3>
            <div className="space-y-4">
              {broadcasts.map(b => (
                <div key={b.id} className="p-4 bg-white/5 rounded-xl border border-white/5">
                  <p className="text-sm">{b.message}</p>
                  <p className="text-[10px] text-[var(--text-muted)] mt-2">
                    {new Date(b.timestamp).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          </Card>
        )}

        {workouts.length > 0 ? workouts.map(workout => (
          <div key={workout.id}>
            <Card className="space-y-4">
              <h3 className="font-bold text-xl">{workout.title}</h3>
              <p className="text-sm text-[var(--text-muted)]">{workout.description}</p>
              <div className="space-y-3">
                {workout.exercises.map((ex: any, i: number) => (
                  <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                    <div>
                      <p className="font-bold">{ex.name}</p>
                      <p className="text-xs text-[var(--text-muted)]">{ex.sets} Sets × {ex.reps} Reps</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )) : (
          <Card className="text-center py-12">
            <Dumbbell className="w-12 h-12 text-[var(--text-muted)] mx-auto mb-4 opacity-20" />
            <p className="text-[var(--text-muted)]">No workouts assigned yet.</p>
          </Card>
        )}

        {myCheckins.length > 0 && (
          <Card className="space-y-4">
            <h3 className="font-bold flex items-center gap-2">
              <History className="w-5 h-5 text-[var(--secondary)]" /> My Check-in History
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {myCheckins.map(ci => (
                <div key={ci.id} className="p-3 bg-white/5 rounded-xl border border-white/5 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-bold">{ci.day}</p>
                    <p className="text-[10px] text-[var(--text-muted)]">{ci.time}</p>
                  </div>
                  <span className={cn(
                    "text-[9px] px-2 py-0.5 rounded-full uppercase font-bold",
                    ci.status === 'approved' ? "bg-green-500/20 text-green-500" : 
                    ci.status === 'rejected' ? "bg-red-500/20 text-red-500" : "bg-yellow-500/20 text-yellow-500"
                  )}>
                    {ci.status}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

// --- Main App ---

function App() {
  const { user, loading, login, logout, isLocalMode } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    // Test connection
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    };
    testConnection();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
        >
          <Dumbbell className="w-12 h-12 text-[var(--primary)]" />
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return <LoginView onLogin={login} />;
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-black text-white">
      {/* Sidebar / Navigation */}
      <nav className="w-full md:w-64 glass border-r border-[var(--border)] p-6 flex flex-col justify-between">
        <div className="space-y-8">
          <div className="flex items-center gap-3">
            <Logo size="md" />
            <h1 className="text-xl font-black tracking-tighter uppercase italic">IronCore</h1>
          </div>

          <div className="space-y-2">
            {user.role === UserRole.SUPER_ADMIN && (
              <>
                <button 
                  onClick={() => setActiveTab('dashboard')}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                    activeTab === 'dashboard' ? "bg-[var(--primary)] text-black font-bold" : "text-[var(--text-muted)] hover:bg-white/5"
                  )}
                >
                  <LayoutDashboard className="w-5 h-5" /> Dashboard
                </button>
                <button 
                  onClick={() => setActiveTab('members')}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                    activeTab === 'members' ? "bg-[var(--primary)] text-black font-bold" : "text-[var(--text-muted)] hover:bg-white/5"
                  )}
                >
                  <Users className="w-5 h-5" /> User Management
                </button>
                <button 
                  onClick={() => setActiveTab('broadcast')}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                    activeTab === 'broadcast' ? "bg-[var(--primary)] text-black font-bold" : "text-[var(--text-muted)] hover:bg-white/5"
                  )}
                >
                  <Megaphone className="w-5 h-5" /> Broadcast
                </button>
              </>
            )}

            {(user.role === UserRole.ADMIN || user.role === UserRole.MANAGER) && (
              <>
                <button 
                  onClick={() => setActiveTab('dashboard')}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                    activeTab === 'dashboard' ? "bg-[var(--primary)] text-black font-bold" : "text-[var(--text-muted)] hover:bg-white/5"
                  )}
                >
                  <LayoutDashboard className="w-5 h-5" /> Dashboard
                </button>
                <button 
                  onClick={() => setActiveTab('members')}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                    activeTab === 'members' ? "bg-[var(--primary)] text-black font-bold" : "text-[var(--text-muted)] hover:bg-white/5"
                  )}
                >
                  <Users className="w-5 h-5" /> Member List
                </button>
                <button 
                  onClick={() => setActiveTab('broadcast')}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                    activeTab === 'broadcast' ? "bg-[var(--primary)] text-black font-bold" : "text-[var(--text-muted)] hover:bg-white/5"
                  )}
                >
                  <Megaphone className="w-5 h-5" /> Broadcast
                </button>
              </>
            )}

            {user.role === UserRole.MEMBER && (
              <button 
                onClick={() => setActiveTab('dashboard')}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all",
                  activeTab === 'dashboard' ? "bg-[var(--primary)] text-black font-bold" : "text-[var(--text-muted)] hover:bg-white/5"
                )}
              >
                <LayoutDashboard className="w-5 h-5" /> My Dashboard
              </button>
            )}
          </div>
        </div>

        <div className="pt-8 border-t border-[var(--border)] space-y-4">
          <div className="flex items-center gap-3 px-2">
            <div className="w-10 h-10 rounded-full bg-zinc-800 border border-[var(--border)] flex items-center justify-center text-xs font-bold">
              {user.name[0]}
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-bold truncate">{user.name}</p>
              <p className="text-[10px] text-[var(--text-muted)] uppercase tracking-widest">{user.role.replace('_', ' ')}</p>
            </div>
          </div>
          <Button variant="danger" onClick={logout} className="w-full flex items-center justify-center gap-2">
            <LogOut className="w-4 h-4" /> Logout
          </Button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-12 overflow-y-auto">
        {isLocalMode && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-2xl flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-yellow-500" />
              <div>
                <p className="text-sm font-bold text-yellow-500">Local Mode Active</p>
                <p className="text-xs text-yellow-500/70">Database writes are disabled until Anonymous Auth is enabled in Firebase Console.</p>
              </div>
            </div>
            <a 
              href="https://console.firebase.google.com/" 
              target="_blank" 
              rel="noreferrer"
              className="text-xs font-bold underline text-yellow-500 hover:text-yellow-400 transition-colors"
            >
              Fix Now
            </a>
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          <motion.div
            key={user.role + activeTab}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === 'dashboard' && (
              <>
                {user.role === UserRole.SUPER_ADMIN && <SuperAdminDashboard isLocalMode={isLocalMode} setActiveTab={setActiveTab} />}
                {(user.role === UserRole.ADMIN || user.role === UserRole.MANAGER) && <StaffDashboard isLocalMode={isLocalMode} setActiveTab={setActiveTab} />}
                {user.role === UserRole.MEMBER && <MemberDashboard user={user} />}
              </>
            )}
            {activeTab === 'members' && (user.role === UserRole.SUPER_ADMIN || user.role === UserRole.ADMIN || user.role === UserRole.MANAGER) && (
              <MemberManagement isLocalMode={isLocalMode} />
            )}
            {activeTab === 'broadcast' && (user.role === UserRole.SUPER_ADMIN || user.role === UserRole.ADMIN) && (
              <BroadcastPanel isLocalMode={isLocalMode} />
            )}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

export default function AppWithBoundary() {
  return (
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  );
}
