import { useState, useEffect } from 'react';
import { 
  signInAnonymously, 
  onAuthStateChanged, 
  signOut,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc,
  collection,
  query,
  where,
  getDocs,
  deleteDoc
} from 'firebase/firestore';
import { auth, db } from '../firebase';
import { UserRole, UserProfile } from '../types';
import { ADMIN_CONFIG } from '../constants';

import { handleFirestoreError, OperationType } from '../lib/firestoreUtils';

export function useAuth() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const [isLocalMode, setIsLocalMode] = useState(false);

  useEffect(() => {
    // Check for local fallback user first
    const localUser = localStorage.getItem('ironcore_fallback_user');
    if (localUser) {
      setUser(JSON.parse(localUser));
      setIsLocalMode(true);
      setLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        const userDoc = await getDoc(doc(db, 'users', fbUser.uid));
        if (userDoc.exists()) {
          setUser(userDoc.data() as UserProfile);
        } else {
          setUser(null);
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (id: string, rememberMe: boolean): Promise<string | null> => {
    try {
      // Simple validation for demo: ID must be 4-10 digits or match admin IDs
      const isAdminId = id === ADMIN_CONFIG.SUPER_ADMIN_ID || id === ADMIN_CONFIG.NORMAL_ADMIN_ID || id === ADMIN_CONFIG.MANAGER_ID;
      const isMemberId = /^\d{4,10}$/.test(id);

      if (!isAdminId && !isMemberId) {
        return "Invalid ID format. Please use a 4 to 10 digit number.";
      }

      // Set persistence based on "Remember Me"
      try {
        await setPersistence(auth, rememberMe ? browserLocalPersistence : browserSessionPersistence);
      } catch (pErr) {
        console.warn('Failed to set persistence:', pErr);
        // Continue anyway, it will just use default persistence
      }

      let fbUser;
      try {
        const result = await signInAnonymously(auth);
        fbUser = result.user;
      } catch (authError: any) {
        console.warn('Firebase Auth restricted, falling back to local session:', authError);
        if (authError.code === 'auth/admin-restricted-operation' || authError.code === 'auth/operation-not-allowed') {
          // Fallback: Create a local mock session if Firebase is restricted
          // This allows the user to see the app even if they haven't enabled Anonymous Auth yet
          const mockUid = `local_${id}`;
          let role = UserRole.MEMBER;
          if (id === ADMIN_CONFIG.SUPER_ADMIN_ID) role = UserRole.SUPER_ADMIN;
          else if (id === ADMIN_CONFIG.NORMAL_ADMIN_ID) role = UserRole.ADMIN;
          else if (id === ADMIN_CONFIG.MANAGER_ID) role = UserRole.MANAGER;

          const profile: UserProfile = {
            uid: mockUid,
            id,
            name: role === UserRole.SUPER_ADMIN ? 'Super Admin (Local)' : role === UserRole.ADMIN ? 'Normal Admin (Local)' : role === UserRole.MANAGER ? 'Manager (Local)' : `Member ${id.slice(-4)} (Local)`,
            role,
            createdAt: Date.now(),
          };
          
          setUser(profile);
          setIsLocalMode(true);
          // Store in local storage for "Remember Me" persistence
          if (rememberMe) {
            localStorage.setItem('ironcore_fallback_user', JSON.stringify(profile));
          }
          return null;
        }
        throw authError;
      }
      
      setIsLocalMode(false);
      // Check if user already exists with this ID
      const usersRef = collection(db, 'users');
      const q = query(usersRef, where('id', '==', id));
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        const existingDoc = querySnapshot.docs[0];
        const existingData = existingDoc.data() as UserProfile;
        
        // If the document's ID is not the current UID, migrate it
        if (existingDoc.id !== fbUser.uid) {
          const newProfile = { ...existingData, uid: fbUser.uid };
          try {
            await setDoc(doc(db, 'users', fbUser.uid), newProfile);
            await deleteDoc(doc(db, 'users', existingDoc.id));
          } catch (err) {
            handleFirestoreError(err, OperationType.WRITE, `users/${fbUser.uid}`);
          }
          setUser(newProfile);
        } else {
          setUser(existingData);
        }
        return null;
      }

      // If user doesn't exist, only allow Super Admin to bootstrap
      if (id !== ADMIN_CONFIG.SUPER_ADMIN_ID) {
        return "Access denied. This ID is not registered. Please contact an administrator.";
      }

      let role = UserRole.SUPER_ADMIN;
      const profile: UserProfile = {
        uid: fbUser.uid,
        id,
        name: 'Super Admin',
        role,
        createdAt: Date.now(),
      };

      try {
        await setDoc(doc(db, 'users', fbUser.uid), profile);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `users/${fbUser.uid}`);
      }
      setUser(profile);
      return null;
    } catch (error: any) {
      console.error('Login failed:', error);
      
      if (error.code === 'auth/admin-restricted-operation') {
        return "ACTION REQUIRED: Anonymous Sign-in is disabled. Please go to Firebase Console > Authentication > Sign-in method and enable 'Anonymous'.";
      }
      
      if (error.code === 'auth/operation-not-allowed') {
        return "Firebase configuration error: Anonymous auth is not enabled in your project settings.";
      }

      return error.message || "An unexpected error occurred during login.";
    }
  };

  const logout = async () => {
    localStorage.removeItem('ironcore_fallback_user');
    await signOut(auth);
    setUser(null);
  };

  return { user, loading, login, logout, isLocalMode };
}
