import React from 'react';
import { Dumbbell } from 'lucide-react';
import { cn } from '../lib/utils';

interface LogoProps {
  className?: string;
  iconClassName?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const Logo = ({ className, iconClassName, size = 'md' }: LogoProps) => {
  const sizes = {
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-20 h-20"
  };

  const iconSizes = {
    sm: "w-4 h-4",
    md: "w-6 h-6",
    lg: "w-10 h-10"
  };

  return (
    <div className={cn(
      "bg-[var(--primary)] rounded-xl flex items-center justify-center neon-glow",
      sizes[size],
      className
    )}>
      <Dumbbell className={cn("text-black", iconSizes[size], iconClassName)} />
    </div>
  );
};
