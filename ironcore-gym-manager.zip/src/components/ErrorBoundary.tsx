import React, { Component, ReactNode } from 'react';
import { XCircle } from 'lucide-react';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = { hasError: false, error: null };
  props: ErrorBoundaryProps;

  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.props = props;
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      let errorInfo = null;
      try {
        errorInfo = JSON.parse(this.state.error.message);
      } catch (e) {}

      return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-black text-white">
          <div className="glass p-6 rounded-2xl max-w-md w-full border-red-500/50 bg-red-500/5">
            <div className="flex flex-col items-center text-center space-y-4">
              <XCircle className="w-12 h-12 text-red-500" />
              <h2 className="text-xl font-bold">Something went wrong</h2>
              <p className="text-sm opacity-70">
                {errorInfo ? `Firestore Error: ${errorInfo.operationType} at ${errorInfo.path}` : this.state.error?.message || 'Unknown error'}
              </p>
              <button 
                onClick={() => window.location.reload()} 
                className="px-6 py-2 bg-emerald-500 text-black font-bold rounded-xl hover:shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all"
              >
                Reload App
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
