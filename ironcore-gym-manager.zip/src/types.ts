export enum UserRole {
  SUPER_ADMIN = 'SUPER_ADMIN',
  ADMIN = 'ADMIN',
  MANAGER = 'MANAGER',
  MEMBER = 'MEMBER',
}

export interface UserProfile {
  uid: string;
  id: string; // The ID provided by user (e.g., phone number)
  name: string;
  role: UserRole;
  email?: string;
  photoURL?: string;
  createdAt: number;
}

export interface Workout {
  id: string;
  title: string;
  description: string;
  exercises: Exercise[];
  createdBy: string;
  createdAt: number;
}

export interface Exercise {
  name: string;
  sets: number;
  reps: string;
  weight?: string;
}

export interface CheckIn {
  id: string;
  memberId: string;
  memberName: string;
  timestamp: number;
  day?: string;
  time?: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: number;
  type: 'info' | 'alert' | 'success';
}
