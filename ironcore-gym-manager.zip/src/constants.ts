export const ADMIN_CONFIG = {
  SUPER_ADMIN_ID: '8921076753',
  NORMAL_ADMIN_ID: '8848/359766',
  MANAGER_ID: '1234567890',
};

export const THEME = {
  colors: {
    background: '#0A0A0A',
    surface: '#141414',
    primary: '#00FF00', // Neon green for that gym vibe
    secondary: '#FF6321', // Bold orange
    text: '#FFFFFF',
    textMuted: '#A0A0A0',
    border: '#262626',
  }
};
